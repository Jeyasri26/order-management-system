package ordermanagementdao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Connect.DBUtil;
import orderprocess.*;
import users.OrderNotFoundException;
import users.UserNotFoundException;

abstract class IOrderManagementRepository {

    
    private Connection con;
	PreparedStatement stat;

    public IOrderManagementRepository(){
    con=DBUtil.getConnect();
    }

    public void createOrd(int userId, String username, int productId, String productName){
        try{
            stat=con.prepareStatement("insert into  table orders (? ,?,?,?)");

			stat.setInt(1, u.getUserId());
			stat.setString(2, u.getUsername());
			stat.setInt(3, p.getproductId());
			stat.setString( 4, p.getProductName());
			
			stat.executeUpdate();
         
        }
        catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
    }
    public void createProd( int productId, String productName , String description , double price , int quantityInStock, String type ){
        try{
            stat=con.prepareStatement("insert into  table Product (? ,?,?,?)");

			stat.setInt(1, p.getProductId());
			stat.setString(2, p.getProductName());
			stat.setString(3, p.getDescription());
			stat.setDouble(4, p.getPrice());
            stat.setInt(1, p.getQuantityInStock());
			stat.setString(2, p.getType());
			
			stat.executeUpdate();
         
        }
        catch(Exception e)
		{
			System.out.println(e.getMessage());
		}

    }



    public void createUsr(int userId, String name, String password, String role){
        try{
            stat=con.prepareStatement("insert into  table User (? ,?,?,?)");

			stat.setInt(1, u.getUserId());
			stat.setString(2, u.getUsername());
			stat.setString(2, u.getPassword());
			stat.setInt(3, u.getRole());

            stat.executeUpdate();
         
        }
        catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
    }


    public void cancelOrd(int userId, int orderId){
        try
		{
		u.takeuserId();
		}
		catch ( UserNotFoundException e) {
			System.out.println(e.getMessage());
		}
        catch(OrderNotFoundException e){
            System.out.println(e.getMessage());
        }
		
		
    }

    public void getOrderByUsr(int){
        try{
            stat=con.prepareStatement("insert into  table User (? ,?,?,?)");

			stat.setInt(1, u.getUserId());
			stat.setString(2, u.getUsername());
			stat.setString(2, u.getPassword());
			stat.setInt(3, u.getRole());

            stat.executeUpdate();
         
        }
        catch(Exception e)
		{
			System.out.println(e.getMessage());
		}

    }

    public void getAllProd(){
    try
		{
			stat=con.prepareStatement("select * from Product where userId=?");
            stat.setInt(1, u.getUserId());
			ResultSet r=stat.executeQuery();
			while(r.next()){
             System.out.println("productId is "+r.getInt(1)+" "+
            "productName is "+r.getString(2)+" "+
            "description is "+r.getString(3)+" "+
            "price is "+r.getDouble(4)+" "+
            "quantityInStock is "+r.getString(5)+" "+
            "type is"+" "+r.getInt(6));
			}
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}

        
    }
}




    

