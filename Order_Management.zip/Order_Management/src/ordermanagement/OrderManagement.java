package ordermanagement;

import java.util.*;

public class OrderManagement {
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args){
        OrderManagement ordm= new OrderManagement();
        while (true){
            System.out.println("1. createUser");
            System.out.println("2. createProduct");
            System.out.println("3. cancelOrder");
            System.out.println("4. getAllProducts");
            System.out.println("5. getOrderbyUser");
            System.out.println("6. exit");
            int ch=sc.nextInt();
            if(ch==1)
            {
                  ordm.createUser();
                  break;
            }
            else if(ch==2)
            {
                  ordm.createProduct();
                  break;
            }
            else if(ch==3)
            {
                  ordm.cancelOrder();
                  break;
                }
    
            else if(ch==4)
            {
                  ordm.getAllProducts();
                  break;
                }
            
            else if(ch==5)
            {
                  ordm.getOrderbyUser();
                  break;
                }
            
            else if(ch==6){
                  System.exit(0);
                  break;
            }
            else{
                return;
            }          
        }

        }
    }
