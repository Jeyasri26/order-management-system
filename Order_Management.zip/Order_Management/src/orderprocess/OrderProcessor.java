package orderprocess;

import java.util.Scanner;

import ordermanagement.OrderManagement;
import products.Product;
import users.User;

public class OrderProcessor {
    Scanner sc;
	OrderManagement om;
    public OrderProcessor()
	{
		sc=new Scanner(System.in);
		om=new OrderManagement();


	}
    public void createUser()
	{
		User u=new User();
		System.out.println("Enter UserId: ");
		u.setUserId(sc.nextInt());
		sc.nextLine();
		System.out.println("Enter User name: ");
		u.setUsername(sc.nextLine());
		sc.nextLine();
		System.out.println("Enter password: ");
		u.setPassword(sc.nextLine());
		sc.nextLine();
		System.out.println("Enter role: ");
		u.setRole(sc.nextLine());
		
        om.createUsr(u);
    
    }

	public void createProduct()
	{
		Product p = new Product();
		System.out.println("Enter ProductId: ");
		p.setProductId(sc.nextInt());
		sc.nextLine();
		System.out.println("Enter Product name: ");
		p.setProductName(sc.nextLine());
		sc.nextLine();

		System.out.println("Enter decription: ");
		p.setDescription(sc.nextLine());
		sc.nextLine();
		System.out.println("Enter Price: ");
		p.setPrice(sc.nextDouble());
		System.out.println("Enter quantity: ");
		p.setQuantityInStock(sc.nextInt());
		sc.nextLine();

		System.out.println("Enter type: ");
		p.setType(sc.nextLine());

		om.createProd(p);
	
		
	}


    public void createOrder()
	{
		Product p = new Product();
		User u=new User();
		System.out.println("Enter UserId: ");
		u.setUserId(sc.nextInt());
		sc.nextLine();
		System.out.println("Enter User name: ");
		u.setUsername(sc.nextLine());

		System.out.println("Enter ProductId: ");
		p.setProductId(sc.nextInt());
		sc.nextLine();
		System.out.println("Enter Product name: ");
		p.setProductName(sc.nextLine());
		
		om.createOrd(p);
		om.createOrd(u);
		
		
     }

	 public void cancelOrder()
	 {
		Product p = new Product();
		User u=new User();

		System.out.println("Enter UserId: ");
		u.setUserId(sc.nextInt());
		sc.nextLine();
		System.out.println("Enter ProductId: ");
		p.setProductId(sc.nextInt());
		sc.nextLine();

		om.cancelOrd(p);
		om.cancelOrd(u);

	 }

	 public void getAllProducts(){
		Product p = new Product();
		System.out.println("Enter ProductId: ");
		p.setProductId(sc.nextInt());
		sc.nextLine();
		System.out.println("Enter Product name: ");
		p.setProductName(sc.nextLine());
		sc.nextLine();
		System.out.println("Enter decription: ");
		p.setDescription(sc.nextLine());
		sc.nextLine();
		System.out.println("Enter Price: ");
		p.setPrice(sc.nextDouble());
		System.out.println("Enter quantity: ");
		p.setQuantityInStock(sc.nextInt());
		sc.nextLine();

		System.out.println("Enter type: ");
		p.setType(sc.nextLine());

		om.getAllProd(p);


	  } 
     public void getOrderByUser(){

		Product p = new Product();
		User u=new User();
		System.out.println("Enter UserId: ");
		u.setUserId(sc.nextInt());
		sc.nextLine();
		System.out.println("Enter ProductId: ");
		p.setProductId(sc.nextInt());
		sc.nextLine();
		System.out.println("Enter Product name: ");
		p.setProductName(sc.nextLine());
		om.getOrderbyUsr(u,p);
      
	 }

    
}
