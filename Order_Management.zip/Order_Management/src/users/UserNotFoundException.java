package users;

public enum UserNotFoundException {

    UserNotFoundException(String str) {
	
        super(str);
        
    }
    
    void showMsg()
    {
        
        System.out.println("User not Found ");
    }

    }

