package users;

public class OrderNotFoundException {

   OrderNotFoundException(String str) {
	
        super(str);
        
    }
    
    
    void showMsg()
    {
        
        System.out.println("Order not Found ");
    }

    }
    
